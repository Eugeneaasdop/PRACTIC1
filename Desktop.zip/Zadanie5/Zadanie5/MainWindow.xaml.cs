﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zadanie5
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int Btn1 = 0;
        int Btn2 = 0;
        int Btn3 = 0;
        int Btn4 = 0;
        int Btn5 = 0;
        int Btn6 = 0;
        int Btn7 = 0;
        int Btn8 = 0;
        int Btn9 = 0;
        public MainWindow()
        {
            InitializeComponent();
            if (Btn7 == 1 && Btn8 == 1 && Btn9 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            if(btnx.IsChecked == true && Btn1 == 0)
            {
                Btn1 = 1;
                btn1.Content = "X";
                btnx.IsChecked = false;
                btno.IsChecked = true;
            }
            else
            {
                if(btno.IsChecked == true && Btn1 == 0)
                {
                    Btn1 = 2;
                    btn1.Content = "O";
                    btno.IsChecked = false;
                    btnx.IsChecked = true;
                }
            }
            if(Btn1 == 1 && Btn2 == 1 && Btn3 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 1 && Btn4 == 1 && Btn7 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 1 && Btn5 == 1 && Btn9 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 2 && Btn2 == 2 && Btn3 == 2)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 1 && Btn4 == 2 && Btn7 == 2)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 2 && Btn5 == 2 && Btn9 == 2)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            if (btnx.IsChecked == true && Btn1 == 0)
            {
                Btn2 = 1;
                btn2.Content = "X";
                btnx.IsChecked = false;
                btno.IsChecked = true;
            }
            else
            {
                if (btno.IsChecked == true && Btn2 == 0)
                {
                    Btn2 = 2;
                    btn2.Content = "O";
                    btno.IsChecked = false;
                    btnx.IsChecked = true;
                }
            }
            if (Btn1 == 1 && Btn2 == 1 && Btn3 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn2 == 1 && Btn2 == 5 && Btn3 == 8)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 2 && Btn2 == 2 && Btn3 == 2)
            {
                MessageBox.Show("Победили нолики", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn2 == 2 && Btn5 == 2 && Btn8 == 2)
            {
                MessageBox.Show("Победили нолики", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            if (btnx.IsChecked == true && Btn3 == 0)
            {
                Btn3 = 1;
                btn3.Content = "X";
                btnx.IsChecked = false;
                btno.IsChecked = true;
            }
            else
            {
                if (btno.IsChecked == true && Btn3 == 0)
                {
                    Btn3 = 2;
                    btn3.Content = "O";
                    btno.IsChecked = false;
                    btnx.IsChecked = true;
                }
            }
            if (Btn1 == 1 && Btn2 == 1 && Btn3 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn3 == 1 && Btn6 == 1 && Btn9 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn3 == 1 && Btn5 == 1 && Btn7 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 2 && Btn2 == 2 && Btn3 == 2)
            {
                MessageBox.Show("Победили нолики", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn3 == 2 && Btn6 == 2 && Btn9 == 2)
            {
                MessageBox.Show("Победили нолики", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn3 == 2 && Btn5 == 2 && Btn7 == 2)
            {
                MessageBox.Show("Победили нолики", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            if (btnx.IsChecked == true && Btn4 == 0)
            {
                Btn4 = 1;
                btn4.Content = "X";
                btnx.IsChecked = false;
                btno.IsChecked = true;
            }
            else
            {
                if (btno.IsChecked == true && Btn4 == 0)
                {
                    Btn4 = 2;
                    btn4.Content = "O";
                    btno.IsChecked = false;
                    btnx.IsChecked = true;
                }
            }
            if (Btn4 == 1 && Btn5 == 1 && Btn6 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 1 && Btn4 == 1 && Btn7 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn4 == 2 && Btn5 == 2 && Btn6 == 2)
            {
                MessageBox.Show("Победили нолики", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 2 && Btn4 == 2 && Btn7 == 2)
            {
                MessageBox.Show("Победили нолики", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            if (btnx.IsChecked == true && Btn5 == 0)
            {
                Btn5 = 1;
                btn5.Content = "X";
                btnx.IsChecked = false;
                btno.IsChecked = true;
            }
            else
            {
                if (btno.IsChecked == true && Btn5 == 0)
                {
                    Btn5 = 2;
                    btn5.Content = "O";
                    btno.IsChecked = false;
                    btnx.IsChecked = true;
                }
            }
            if (Btn1 == 1 && Btn5 == 1 && Btn9 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn2 == 1 && Btn5 == 1 && Btn8 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn3 == 1 && Btn5 == 1 && Btn7 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn4 == 1 && Btn5 == 1 && Btn6 == 1)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn1 == 2 && Btn5 == 2 && Btn9 == 2)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (Btn2 == 2 && Btn5 == 2 && Btn8 == 2)
            {
                MessageBox.Show("Победили крестки", "Поздравляем", MessageBoxButton.OK, MessageBoxImage.Information);
            }

        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn7_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {

        }

        private void game_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
