﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace zadanie2
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            double number1 = double.Parse(Txt.Text);
            double number2 = double.Parse(Txt.Text);
            double sum = number1 + number2;
            double raz = number1 - number2;
            double del = number1 / number2;
            double proiz = number1 * number2;
            Sum.Text = sum.ToString();
            Raz.Text = raz.ToString();
            Delen.Text = del.ToString();
            Proiz.Text = proiz.ToString();
        }
    }
}
